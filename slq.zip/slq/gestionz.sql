-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : jeu. 16 juin 2022 à 14:18
-- Version du serveur :  5.7.31
-- Version de PHP : 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `gestionz`
--

-- --------------------------------------------------------

--
-- Structure de la table `creche`
--

DROP TABLE IF EXISTS `creche`;
CREATE TABLE IF NOT EXISTS `creche` (
  `id_creche` int(11) NOT NULL AUTO_INCREMENT,
  `nom_creche` varchar(50) DEFAULT NULL,
  `adresse` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_creche`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `personnel`
--

DROP TABLE IF EXISTS `personnel`;
CREATE TABLE IF NOT EXISTS `personnel` (
  `id_perso` int(11) NOT NULL AUTO_INCREMENT,
  `definition_perso` varchar(50) DEFAULT NULL,
  `nom_perso` varchar(50) DEFAULT NULL,
  `prenom_perso` varchar(50) DEFAULT NULL,
  `is_admin` tinyint(1) DEFAULT NULL,
  `is_directeur` tinyint(1) DEFAULT NULL,
  `is_auxiliaire` tinyint(1) DEFAULT NULL,
  `Id_creche` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_perso`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `tache`
--

DROP TABLE IF EXISTS `tache`;
CREATE TABLE IF NOT EXISTS `tache` (
  `id_tache` int(11) NOT NULL AUTO_INCREMENT,
  `type_de_tache` varchar(100) DEFAULT NULL,
  `date_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `temperature` varchar(50) DEFAULT NULL,
  `id_perso` int(11) NOT NULL,
  `id_creche` int(11) NOT NULL,
  `id_tache_unique` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_tache`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `tache_unique`
--

DROP TABLE IF EXISTS `tache_unique`;
CREATE TABLE IF NOT EXISTS `tache_unique` (
  `id_tache_unique` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(200) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id_tache_unique`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `tache_unique`
--

INSERT INTO `tache_unique` (`id_tache_unique`, `type`, `description`) VALUES
(1, 'Salle Pro', 'Nettoyage: Surface et plan de travail.'),
(2, 'Salle Pro', 'Nettoyage: Porte et poignets.'),
(3, 'Salle Pro', 'Nettoyage: Céramique éviers *3 et robinet. '),
(4, 'Salle Pro', 'Nettoyage: Intérieur de placards/micro-onde/carrelage/bureau.\r\n'),
(5, 'Salle de Change', 'Nettoyage: Surface (évier*2, robinetterie*2), plan de change complet'),
(6, 'Salle de change', 'Nettoyage: Portes/poignets'),
(7, 'Salle de change', 'Nettoyage toilette: Chaise d\'eau, céramique '),
(8, 'Salle de change', 'Nettoyage étagère des panières.'),
(9, 'Biberonnerie', 'Vider la biberonnerie et frigos des aliments.'),
(10, 'Biberonnerie', 'Nettoyage surface: Evier, robinetterie, plan de travail, poubelle.'),
(11, 'Biberonnerie', 'Nettoyage portes et poignets: Frigo, biberonnerie'),
(12, 'Biberonnerie', 'Nettoyage intérieur: Frigo, étagère.'),
(13, 'Section - Sol', 'Nettoyage surface: meuble jeu/ dinette, tables chaises, blocs moteurs, tapis, poignets'),
(14, 'Section - Sol', 'Nettoyage sol: Entrée, toilette, section.'),
(15, 'Section - Sol', 'Etagère des paniers.  '),
(16, 'Salle de Vie', 'Aérer la crèche'),
(17, 'Salle de Vie', 'Désinfecter les poignées.'),
(18, 'Salle de Vie', 'Nettoyage: Hublots et vitres'),
(19, 'Salle de Vie', 'Désinfecter les tapis et les coins bebe '),
(20, 'Salle de Vie', 'Passer la gaz et la serpillère'),
(21, 'Dortoir', 'Passer la gaz'),
(22, 'Dortoir', 'Désinfecter: Toboggan, hublots et poignets.'),
(23, 'Dortoir', 'Enlever et laver les draps '),
(24, 'Dortoir', 'Désinfecter les lits');

-- --------------------------------------------------------

--
-- Structure de la table `trace`
--

DROP TABLE IF EXISTS `trace`;
CREATE TABLE IF NOT EXISTS `trace` (
  `id_tache` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(150) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `photo` varchar(150) DEFAULT NULL,
  `com` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id_tache`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
